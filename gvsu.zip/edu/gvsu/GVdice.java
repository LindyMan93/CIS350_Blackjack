package edu.gvsu;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/*****************************************************************
A graphical representation of a six-sided die with various controls over the appearance.  Current
value is constrained between 1 and 6. You can control the size and color of the dice.
<img src="Dice.jpg" width="250" height="60">   
<h4>An Example</h4>
<blockquote><pre><code>
GVdice die1 = new GVdice( );
GVdice die2 = new GVdice (50);
die1.roll( );
int result = die2.getValue( ); 
</code></pre></blockquote>
<br>Source code: <a href="GVdice.java">GVdice.java</a>
<P> 
@author Scott Grissom
@version 1.3 September 4, 2005
*****************************************************************/
public class GVdice extends JPanel{
/** current value of the die */
private int myValue; 

/** current size in pixels */
private int mySize;

/** dot size in pixels defined by overall die size */ 
private int dotSize;

/** offset in pixels for the left row of dots */ 
private int left;

/** offset in pixels for the right row of dots */ 
private int right;

/** offset in pixels for the middle dot */ 
private int middle;
private int NUM_ROLLS = 5;

/** color of the dots */
private Color myColor;

/** background color */
//private Color myBackground;


/*****************************************************************
constructor creates a die of specified size X size pixels

@param size the length of each side in pixels
*****************************************************************/
public GVdice(int size) {
// initialize the die and determine display characteristics 
mySize = size; 
dotSize = mySize / 5; 
left = (mySize-(3*dotSize))/4; 
right = mySize - left - dotSize; 
middle = (mySize - dotSize) /2;
setBackground(Color.white);
//myBackground = new Color(255,255,255);
myColor = new Color(0,0,0); 
myColor = Color.black; 
setSize(size+1,size+1); 
setPreferredSize(new Dimension(size+1, size+1));
//setLayout(null); 
myValue = (int) (Math.random()*6)+1;
t = new javax.swing.Timer(150, new Animator());

}


/*****************************************************************
* default constructor creates a die of size 100 X 100 pixels
*****************************************************************/
public GVdice() {
this(100);
}


/*****************************************************************
Sets the color of the dots
@param c a Java Color object such as Color.red
*****************************************************************/
public void setForeground(Color c){
myColor = c;
    super.setForeground(c);
}

private javax.swing.Timer t;

/*****************************************************************
Roll the die obtaining a random value in the range 1 - 6.
@param none
*****************************************************************/
public void roll (){
if (!t.isRunning())
    t.start();
}


private class Animator implements ActionListener{
int count = 0;
public void actionPerformed(ActionEvent e){
        myValue = (int) (Math.random()*6)+1; 
        repaint();
	count++;
	if (count == NUM_ROLLS){
		count=0;
		t.stop();
	}
}
}

/*****************************************************************
gets the current value of the die (1 - 6)

@return the current value of the die
*****************************************************************/
public int getValue(){
	// wait until animation stops
	while (t.isRunning());
return myValue;
}


/*****************************************************************
Redraw the die - generally not directly called
@param g the graphics context for the panel
@return none
*****************************************************************/
public void paintComponent(Graphics g){
// paint background
super.paintComponent(g);
g.setColor(getBackground());
g.fillRect(0,0,mySize,mySize);

// point outline
g.setColor(myColor);
g.draw3DRect(0,0,mySize,mySize,true); 
// paint dots    
switch (myValue){   
    case 1:
        g.fillOval (middle,middle,dotSize,dotSize); 
        break;
    case 2:
        g.fillOval (left,left,dotSize,dotSize); 
        g.fillOval (right,right,dotSize,dotSize); 
        break;
    case 3:
        g.fillOval (middle,left,dotSize,dotSize); 
        g.fillOval (middle,middle,dotSize,dotSize); 
        g.fillOval (middle,right,dotSize,dotSize); 
        break;
    case 5:     g.fillOval (middle,middle,dotSize,dotSize);
        // fall throught and paint four more dots
    case 4:
        g.fillOval (left,left,dotSize,dotSize); 
        g.fillOval (left,right,dotSize,dotSize); 
        g.fillOval (right,left,dotSize,dotSize); 
        g.fillOval (right,right,dotSize,dotSize); 
        break;
    case 6:
        g.fillOval (left,left,dotSize,dotSize); 
        g.fillOval (left,middle,dotSize,dotSize); 
        g.fillOval (left,right,dotSize,dotSize); 
        g.fillOval (right,left,dotSize,dotSize); 
        g.fillOval (right,middle,dotSize,dotSize); 
        g.fillOval (right,right,dotSize,dotSize); 
        break;
    }   

}

    
    
}
