package edu.gvsu;

/**
 * This class serves as the user interface
 * for creating sorting visualizations.
 *
 * @author michael j. marsiglia
 * @author scott grissom
 * @version $Revision: 1.3 $
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.util.List;


public class GVsortPanel extends JPanel implements ActionListener {

	/** constants for normalColor */
	static Color normalColor = Color.blue;
	/** constants for heighlightColor */
	static Color highlightColor = Color.yellow;
	/** constants for moveColor */
	static Color moveColor = Color.red;
	/** constants for backgroundColor */
	static Color backgroundColor = Color.white;
	/** constants for tmpColor */
	static Color tmpColor = Color.black;

	/** set of highlighted values */
	protected Set highlighted;
		
	/** internal values for height */
	protected static int panelHeight;
	/** internal values for width */
	protected static int panelWidth;

	/** pointer to the current state */
	protected SortState currentState;

	/** List of all states */
	protected List states;

	/** internal list */
	protected int[] list;
	/** copy of initial list */
	protected int[] i_list;

	/** the jump value */
	protected int jump;
	
	/** Our Panels timer */
	protected javax.swing.Timer timer;

	
	
	/**
	 * Creates a new sort panel around an array
	 * and using a certain size.
	 * @param array the underlying array
	 * @param d dimension to make the panel
	 */
	public GVsortPanel(int[] array, Dimension d) {
		super();
		// build stack
		states = Collections.synchronizedList(new LinkedList());
		highlighted = new HashSet();
		
		panelHeight = d.height;
		panelWidth = d.width;
		timer = new javax.swing.Timer(24, this);
				
		// hide the tmp bar
		setTmpColor(getBackgroundColor());
		// sets the initial speed
		setSpeed(10);
				
		
		changeArray(array);
		
		
	}
	
	/**
	 * Default constructor, builds SortPanel from 1 to 10
	 * with no duplicates and a default size
 	 */
	public GVsortPanel() {
		this(GVsortPanel.orderedArray(1, 10));
	}

	/**
	 * Builds a SortPanel using a custom array and default size
	 */
	public GVsortPanel(int[] array) {
		this(array, new Dimension(500, 540));
	}
	
	/**
	 * Gets the preferred Size
	 */
	public Dimension getPreferredSize() {
		return new Dimension(panelWidth, panelHeight);
	}

	/**
	 * Gets the minimum Size
	 */
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	/**
	 * Gets the maximum Size
	 */
	public Dimension getMaximumSize() {
		return getPreferredSize();
	}

	/**
	 * Sets the preferred Size
	 * (Does nothing, must use constructor and only set the dimension once)
	 */
	public void setPreferredSize(Dimension d) {
		// nothing
	}

	/**
	 * Sets the minimum Size
	 * (Does nothing, must use constructor and only set the dimension once)
	 */
	public void setMinimumSize(Dimension d) {
		// nothing
	}

	/**
	 * Sets the maximum Size
	 * (Does nothing, must use constructor and only set the dimension once)
	 */
	public void setMaximumSize(Dimension d) {
		// nothing
	}

	/**
	 * Sets the Size
	 * (Does nothing, must use constructor and only set the dimension once)
	 */
	public void setSize(int x, int y) {
		// nothing
	}
	
	/**
	 * Paints the current state of this panel
	 * @param g The graphics state of this component
	 */
	public void paintComponent(Graphics g) {
		Insets insets = getInsets();
		int top = insets.top;
		int left = insets.left;
		int totalWidth = getWidth() - insets.left - insets.right;
		int totalHeight = getHeight() - insets.top - insets.bottom;

		// color background
		g.setColor(backgroundColor);
		g.fillRect(left, top, totalWidth, totalHeight);
		currentState.paintState(g);
	}

	/**
	 * Builds an ordered array from start to stop
	 *
	 * @param start Number you want to be first index in array
	 * @param stop Number you want to the last index in the array
	 */
	public static int[] orderedArray(int start, int stop) {
		int[] array;
		int amount;
		if (start > stop) {
			amount = start - stop;
			array = new int[amount];
			for (int i = 0; i < amount; i++) {
				array[i] = start;
				start--;
			}
			return array;
		}
		amount = stop - start;
		array = new int[amount];
		for (int i = 0; i < amount; i++) {
			array[i] = start;
			start++;
		}
		return array;
	}
				
			
	/**
	 * creates a random array
	 * exceptions will throw
	 * (no error checking, must give valid inputs)
	 *
	 * @param noRepeats True if you do not want repeats
	 * @param high Possible High number
	 * @param low Possible Low number
	 * @param amount Length of array
	 * @return Random array
	 */
	public static int[] randomArray(
			boolean noRepeats, int high, int low, int amount) {
		Random r = new Random();
		int[] l = new int[amount];

		// load the list
		if (noRepeats) {
			// build a tmp ArrayList
			ArrayList al = new ArrayList();
			for (int i = low; i < (high + 1); i++) {
				al.add(new Integer(i));
			}

			for (int i = 0; i < amount; i++) {
				l[i] = ((Integer) al.remove(r.nextInt(al.size()))).intValue();
			}
		} else {
			int diff = (high - low);
			for (int i = 0; i < amount; i++) {
				l[i] = ((r.nextInt(diff) + 1) + low);
			}
		}
		return l;
	}

	/**
	 * loads a new array and resets data
	 *
	 * @param array the new array
	 */
	public void changeArray(int [] array) {
		states.clear();
		highlighted.clear();
		// find the biggest and make it the tmp bar
		int length = array.length;
		list = new int[length + 1];
		int largest = -1;
		for (int i = 0; i < length; i++) {
			if (array[i] > largest) {
				largest = array[i];
			}
			// copy this value
			System.arraycopy(array, 0, list, 0, (list.length - 1));
			list[length] = largest;
		}
		// assign current state
		currentState = new SortState(list);
		// push current state
		states.add(currentState);
						
		i_list = new int[length + 1];
		System.arraycopy(list, 0, i_list, 0, (list.length));

		repaint();
	}

	/**
	 * Gets the length of SortSimulation
	 *
	 * @return amount of sort bars
	 */
	public int getLength() {
		if (list.length == 0) {
			return 0;
		} else {
			return list.length - 1;
		}
	}

	/**
	 * Gets the widgets background color
	 *
	 * @return new color
	 */
	public Color getBackgroundColor() {
		return backgroundColor;
	}
	
	/**
	 * Gets the widgets tmp color
	 *
	 * @return new color
	 */	
	public Color getTmpColor() {
		return tmpColor;
	}

	/**
	 * Gets the widgets highlight color
	 *
	 * @return new color
	 */	
	public Color getHighlightColor() {
		return highlightColor;
	}

	/**
	 * Gets the widgets normal color
	 *
	 * @return new color
	 */	
	public Color getNormalColor() {
		return normalColor;
	}	

	/**
	 * Gets the widgets move color
	 *
	 * @return new color
	 */	
	public Color getMoveColor() {
		return moveColor;
	}	

	/**
	 * Changes the widgets background color
	 *
	 * @param c new color
	 */
	public void setBackgroundColor(Color c) {
		backgroundColor = c;
		repaint();
	}
	
	/**
	 * Changes the widgets tmp color
	 *
	 * @param c new color
	 */	
	public void setTmpColor(Color c) {
		tmpColor = c;
		repaint();
	}

	/**
	 * Changes the widgets highlight color
	 *
	 * @param c new color
	 */	
	public void setHighlightColor(Color c) {
		highlightColor = c;
		repaint();
	}

	/**
	 * Changes the widgets normal color
	 *
	 * @param c new color
	 */	
	public void setNormalColor(Color c) {
		normalColor = c;
		repaint();
	}	

	/**
	 * Changes the widgets move color
	 *
	 * @param c new color
	 */	
	public void setMoveColor(Color c) {
		moveColor = c;
		repaint();
	}

	/**
	 * highlights a specific index
	 *
	 * @param index
	 */
	public void highlight(int index) {
		if (index == list.length) {
			throw new NullPointerException("out of bounds");
		}
		highlighted.add(new Integer(index));
		currentState.setHighlighted(
				(HashSet) (((HashSet)highlighted).clone()));
		repaint();
	}
		
	/**
	 * Gets the int a certain index
	 *
	 * @param n index number to get
	 * @return value at that index
	 */
	public int get(int n) {
		// the real array is one to big for the user
		if (n == list.length) {
			throw new NullPointerException("Out of bounds");
		}
		return list[n];
	}

	/**
	 * Compares the two values
	 * using Integer.compareTo method
	 *
	 * @param n1 first index
	 * @param n2 second index
	 * @return result of Integer.compareTo
	 */
	public int compare(int n1, int n2) {
		// the real array is one to big for the user
		if (n1 == list.length || n2 == list.length) {
			throw new NullPointerException("Out of bounds");
		}		
		Integer one = new Integer(list[n1]);
		return one.compareTo(new Integer(list[n2]));
	}
	
	/**
	 * Swaps the two numbers both internally and visually
	 *
	 * @param s1 First index to swap
	 * @param s2 Second index to swap
	 */
	public void swap(final int s1, final int s2) {
						
		try {
			SortState state;
			if (s2 != (list.length - 1)) {
				state = new SortState(list, s1, s2);
			} else {
				state = new SortState(list, s1);
			}
			
			state.setHighlighted((HashSet) (((HashSet)highlighted).clone()));
			
			// swap the two values
			int tmp = list[s1];
			list[s1] = list[s2];
			list[s2] = tmp;
	
			states.add(state);
		} catch (ArrayIndexOutOfBoundsException ex) {
			throw new IllegalArgumentException(
					"Invalid swap index: " + ex.getMessage());
		}

		if (! timer.isRunning()) {
			timer.start();
		}
		
	}

	/**
	 * Pauses and unpauses the SortPanel
	 */
	public void pause() {
		if (timer.isRunning()) {
			timer.stop();
		} else {
			timer.start();
		}
	}
	
	public void printList() {
		System.out.println("LIST: ");
		for (int i = 0; i < list.length - 1; i++) {
			System.out.print(list[i] + " ");
		}
		System.out.println("\nEND LIST");
	}
					
				
	/**
	 * Swaps the number internally and visually with tmp
	 * NOTE: it is the users respondsiblity to change the color
	 * of the tmp bar in order to see the visualization
	 *
	 * @param s1 index to swap with tmp
	 */
	public void swapWithTmp(int s1) {
		swap(s1, list.length - 1);
	}

	/**
	 * The ActionPerformed Method
	 */
	public void actionPerformed(ActionEvent e) {
		// anything that changes GUI should go on the event queue
		EventQueue.invokeLater(new Runnable() 
			{
				public void run() {
					repaint();
					if (! currentState.next(jump)) {
						// look for next state
						ListIterator it =
							states.listIterator(states.indexOf(currentState) + 1);
						if (it.hasNext()) {
							// get next state
							currentState = (SortState) it.next();
						} else {
							// buffer the ending
							if (! currentState.isStartState()) {
								currentState = new SortState(list);
								currentState.setHighlighted(
										(HashSet) (((HashSet)highlighted).clone()));
								states.add(currentState);
							}
																					
							// stop the timer
							if (timer.isRunning()) {
								timer.stop();
							}
						}
						
					} 
					
				}
			}
			);
	}

	/**
	 * Reloads the Panel to its original config
	 */
	public void reload() {
		// reset data
		System.arraycopy(i_list, 0, list, 0, (i_list.length));
		// rewind states
		currentState = (SortState) states.get(0);
		states.clear();
		highlighted.clear();
		currentState.setHighlighted(
				(HashSet) (((HashSet)highlighted).clone()));
		states.add(currentState);
		repaint();
	}
	
	/**
	 * Sets the speed of the jump
	 * number must be greater than 1
	 *
	 * @param n jump ratio
	 * @throws NumberFormatException if number is out of bounds
	 */
	public void setSpeed(int n) {
		if (n < 1) {
			throw new NumberFormatException("Illegal Number: " + n);
		}
		jump = n;
	}
	
	/**
	 * Gets the speed of the jump
	 *
	 * @return jump raito
	 */
	public int getSpeed() {
		// implement me
		return jump;
	}

//  	public static void main(String[] args) throws Exception {
//  		//SortPanel panel =
//  		//new SortPanel(SortPanel.randomArray(true, 100, 1, 10));
//  		SortPanel panel = new SortPanel(SortPanel.orderedArray(1, 10));
//  		JFrame frame = new JFrame("demo");
//  		frame.getContentPane().add(panel);
//  		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//  		frame.pack();
//  		frame.setVisible(true);
//  		panel.setTmpColor(Color.green);		
//  		panel.setSpeed(15);
		
//  		//panel.swap(4, 2);
//  		panel.printList();
		
//  		panel.swapWithTmp(0);
//  		panel.printList();
//  		panel.swapWithTmp(8);
//  		panel.printList();
//  		//panel.swapWithTmp(9);
		
//  	}
	


}










