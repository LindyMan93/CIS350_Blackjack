package edu.gvsu;

/**
 * This class allows the SortPanel to easily
 * encapsalate any individual state.
 * NOTE: TMP bar is always displayed to disable set to
 * same color as background.
 *
 * @author michael j. marsiglia
 * @author scott grissom
 * @version $Revision: 1.1 $
 */

import java.util.*;
import java.awt.*;

public class GVsortState {

	/** current array state */
	protected int[] list;

	protected boolean isStartState;
	
	/** all locations */
	protected Point[] point;
	protected int[] height;
	protected int width;
	protected double padding;
	
	/** internal array index of swap peice 1*/
	protected int swapIndex1;
	protected final int swapIndex1_initialX;
	protected final int swapIndex1_initialY;
	
	/** internal array index of swap peice 2*/
	protected int swapIndex2;
	protected final int swapIndex2_initialX;
	protected final int swapIndex2_initialY;

	/** internal states of movement */
	protected boolean SWAP_NORMAL = true;
	protected boolean RESIZE_TMP_BAR = true;
	protected boolean NORMAL_MOVE_DOWN = true;
	protected boolean NORMAL_MOVE_ACROSS = true;
	protected boolean NORMAL_MOVE_UP = true;
	protected boolean TMP_MOVE_ACROSS = true;
	protected boolean TMP_MOVE_UP = true;

	/** Set of all integers to highlight */
	protected Set highlighted;
	
	/**
	 * Builds a new state around a given
	 * array
	 * @param array stucture to build the state around.
	 * @param index1 an index to swap
	 * @param index2 an index to swap
	 */
	public GVsortState(int[] array, int index1, int index2) {

		// store indexes to swap
		swapIndex1 = index1;
		swapIndex2 = index2;

		int length = array.length;
		list = new int[length];
		point = new Point[length];
		height = new int[length];

		// fill the new array and append the largest element
		// on the end.
		int largest = -1;
		for (int i = 0; i < length; i++) {
			if (array[i] > largest) {
				largest = array[i];
			}
		}
		// copy the array
		System.arraycopy(array, 0, list, 0, list.length);
		
		double usableHeight = (GVsortPanel.panelHeight / 2) * 0.85;
		padding = (GVsortPanel.panelHeight / 2) * 0.05;
		width = (GVsortPanel.panelWidth / (length * 2));
		// everything but the tmp bar
		// figure out starting x for the horizontal centering
		int unpaddedWidth = ((width * ((length - 1) * 2)) + width);
		int x = (SortPanel.panelWidth - unpaddedWidth) / 2;
		
		int y = 0;
		for (int i = 0; i < length - 1; i++) {
			x += width;
			height[i] =
				(int)(((((double)list[i]) / ((double)largest)) * usableHeight)
						+ padding);
			y = (int) ((GVsortPanel.panelHeight / 2) - height[i]);
			point[i] = new Point(x, y);
			// space
			x += width;
		}

		// add tmp bar
		height[length - 1] =
			(int)(((((double)list[length - 1]) / ((double)largest)) * usableHeight)
					+ padding);
		x = (int) ((GVsortPanel.panelWidth / 2) - (width / 2));
		y = (int) (GVsortPanel.panelHeight - height[length - 1] - padding);
				
		point[length - 1] = new Point(x, y);

		// get initial X values of swapIndex's
		if (swapIndex1 != -1) {
			swapIndex1_initialX = point[swapIndex1].x;
			swapIndex1_initialY = point[swapIndex1].y;
		} else {
			swapIndex1_initialX = -1;
			swapIndex1_initialY = -1;
		}
		
		if (swapIndex2 != -1) {
			swapIndex2_initialX = point[swapIndex2].x;
			swapIndex2_initialY = point[swapIndex2].y;
		} else {
			swapIndex2_initialX = -1;
			swapIndex2_initialY = -1;
		}
								
	}

	/**
	 * Sets the currently highlighted states
	 * @param s the set to highlight
	 */
	public void setHighlighted(Set s) {
		highlighted = s;
	}
		
	/**
	 * Builds a new state around a given
	 * array, this state is reserved for swap with tmp
	 * @param array stucture to build the state around.
	 * @param index1 an index to swap
	 */
	public GVsortState(int[] array, int index1) {
		this(array, index1, array.length - 1);
		SWAP_NORMAL = false;
	}

	/**
	 * Builds a new initial state around a given
	 * array. Not made to swap anything.
	 */
	public GVsortState(int[] array) {
		this(array, -1, -1);
		isStartState = true;
	}

	public boolean isStartState() {
		return isStartState;
	}
				
	/**
	 * highlights this index
	 */
	public void highlightIndex(int index) {}

	/**
	 * Algorithm for normal move down
	 * @param jump the amount to jump
	 * @return always returns true, should not be called unless
	 * move is valid.
	 */
	protected boolean normalMoveDown(int jump) {
		int oneStop = (int) (GVsortPanel.panelHeight - height[swapIndex1] - padding);
		int twoStop = (int) (GVsortPanel.panelHeight - height[swapIndex2] - padding);
		point[swapIndex1].y += jump;
		point[swapIndex2].y += jump;
		if (point[swapIndex1].y > oneStop) {
			point[swapIndex1].y = oneStop;
		}
		if (point[swapIndex2].y > twoStop) {
			point[swapIndex2].y = twoStop;
		}
		if (point[swapIndex1].y == oneStop && point[swapIndex2].y == twoStop) {
			NORMAL_MOVE_DOWN = false;
		}
		return true;
	}

	/**
	 * Algorithm for normal move across
	 * @param jump the amount to jump
	 * @return always returns true, should not be called unless
	 * move is valid.
	 */
	protected boolean normalMoveAcross(int jump) {
		int oneStop = swapIndex2_initialX;
		int twoStop = swapIndex1_initialX;
		
		// figure out which way to go
		if (oneStop > twoStop) {
			point[swapIndex1].x += jump;
			if (point[swapIndex1].x > oneStop) {
				point[swapIndex1].x = oneStop;
			}
			point[swapIndex2].x -= jump;
			if (point[swapIndex2].x < twoStop) {
				point[swapIndex2].x = twoStop;
			}
		} else {
			point[swapIndex1].x -= jump;
			if (point[swapIndex1].x < oneStop) {
				point[swapIndex1].x = oneStop;
			}
			point[swapIndex2].x += jump;
			if (point[swapIndex2].x > twoStop) {
				point[swapIndex2].x = twoStop;
			}
		}
		if (point[swapIndex1].x == oneStop && point[swapIndex2].x == twoStop) {
			NORMAL_MOVE_ACROSS = false;
		}
		
		return true;
	}

	/**
	 * Algorithm for normal move up
	 * @param jump the amount to jump
	 * @return always returns true, should not be called unless
	 * move is valid.
	 */
	protected boolean normalMoveUp(int jump) {
		point[swapIndex1].y -= jump;
		point[swapIndex2].y -= jump;
		if (point[swapIndex1].y < swapIndex1_initialY) {
			point[swapIndex1].y = swapIndex1_initialY;
		}
		if (point[swapIndex2].y < swapIndex2_initialY) {
			point[swapIndex2].y = swapIndex2_initialY;
		}
		if (point[swapIndex1].y == swapIndex1_initialY
				&& point[swapIndex2].y == swapIndex2_initialY) {
			NORMAL_MOVE_UP = false;
		}

		return true;
	}
	
		
	/**
	 * Algorithm for normal swapping
	 * @param jump the amount to jump
	 * @return true if state was changed
	 */
	protected boolean swapNormal(int jump) {
		if (NORMAL_MOVE_DOWN) {
			return normalMoveDown(jump);
		}
		if (NORMAL_MOVE_ACROSS) {
			return normalMoveAcross(jump);
		}
		if (NORMAL_MOVE_UP) {
			return normalMoveUp(jump);
		}
		// finished swap
		return false;
	}

	/**
	 * Algorithm for swapping with tmp
	 * @param jump the amount to jump
	 * @return true if state was changed
	 */
	protected boolean swapTmp(int jump) {
		if (RESIZE_TMP_BAR) {
			return tmpResizeBar(jump);
		}
		if (TMP_MOVE_ACROSS) {
			return tmpMoveAcross(jump);
		}
		if (TMP_MOVE_UP) {
			return tmpMoveUp(jump);
		}
		// finished swap
		return false;
	}

	/**
	 * Algorithm for tmp resize bar
	 * @param jump the amount to jump
	 * @return always returns true, should not be called unless
	 * move is valid.
	 */
	protected boolean tmpResizeBar(int jump) {
		// make the bar the same size as the first
		if (height[swapIndex1] != height[swapIndex2]) {
			int diffrence = 0;
			// decide which way to go
			if (height[swapIndex1] < height[swapIndex2]) {
				// shrink
				diffrence = height[swapIndex2] - height[swapIndex1];
				if (jump < diffrence) {
					height[swapIndex2] -= jump;
					point[swapIndex2].y += jump;
				} else {
					height[swapIndex2] -= diffrence;
					point[swapIndex2].y += diffrence;
				}
			} else {
				// grow
				diffrence = height[swapIndex1] - height[swapIndex2];
				if (jump < diffrence) {
					height[swapIndex2] += jump;
					point[swapIndex2].y -= jump;
				} else {
					height[swapIndex2] += diffrence;
					point[swapIndex2].y -= diffrence;
				}
			}
		} else {
			RESIZE_TMP_BAR = false;
		}
		
		return true;
	}

	/**
	 * Algorithm for tmp move across
	 * @param jump the amount to jump
	 * @return always returns true, should not be called unless
	 * move is valid.
	 */
	protected boolean tmpMoveAcross(int jump) {
		int oneStop = (int) (SortPanel.panelHeight - height[swapIndex1] - padding);
		int twoStop = point[swapIndex1].x;
		point[swapIndex1].y += jump;
		if (point[swapIndex1].y > oneStop) {
			point[swapIndex1].y = oneStop;
		}
		
		// figure out which way to go
		if (twoStop < point[swapIndex2].x) {
			point[swapIndex2].x -= jump;
			if (point[swapIndex2].x < twoStop) {
				point[swapIndex2].x = twoStop;
			}
		} else {
			point[swapIndex2].x += jump;
			if (point[swapIndex2].x > twoStop) {
				point[swapIndex2].x = twoStop;
			}
		}
		if (point[swapIndex1].y == oneStop && point[swapIndex2].x == twoStop) {
			TMP_MOVE_ACROSS = false;
		}

		return true;
	}

	/**
	 * Algorithm for tmp move up
	 * @param jump the amount to jump
	 * @return always returns true, should not be called unless
	 * move is valid.
	 */
	protected boolean tmpMoveUp(int jump) {
		int oneStop = swapIndex2_initialX;
		int twoStop = swapIndex1_initialY;
		// move one across
		// figure out which way to go
		if (oneStop < point[swapIndex1].x) {
			point[swapIndex1].x -= jump;
			if (point[swapIndex1].x < oneStop) {
				point[swapIndex1].x = oneStop;
			}
		} else {
			point[swapIndex1].x += jump;
			if (point[swapIndex1].x > oneStop) {
				point[swapIndex1].x = oneStop;
			}
		}
		// move two up
		point[swapIndex2].y -= jump;
		if (point[swapIndex2].y < twoStop) {
			point[swapIndex2].y = twoStop;
		}

		if (point[swapIndex1].x == oneStop && point[swapIndex2].y == twoStop) {
			TMP_MOVE_UP = false;
		}
		return true;
	}
	
	/**
	 * Changes this state to the next position
	 * @param jump the amount to jump
	 * @return true if state was changed
	 */
	public boolean next(int jump) {
		if (isStartState()) {
			return false;
		}
		else if (SWAP_NORMAL) {
			return swapNormal(jump);
		} else {
			// must be swap with tmp
			return swapTmp(jump);
		}
	}

	

	/**
	 * Changes this state to the last position
	 * @param jump the amount to jump
	 * @return true if state was changed
	 */
	public boolean last(int jump) {
		return false;
	}

	/**
	 * Paints the current sort state
	 * @param g The graphics object to paint on
	 */
	public void paintState(Graphics g) {

		int length = list.length - 1;
		// paint the tmp bar
		g.setColor(GVsortPanel.tmpColor);
		g.fillRect(point[length].x, point[length].y,
					width, height[length]);
		
		// paint everything else
		for (int i = 0; i < length; i++) {
			g.setColor(GVsortPanel.normalColor);
			if (i == swapIndex1 || i == swapIndex2) {
				g.setColor(SortPanel.moveColor);
			}
			// highlight overrides swap color
			if (highlighted != null && highlighted.contains(new Integer(i))) {
				g.setColor(GVsortPanel.highlightColor);
			}
						
			g.fillRect(point[i].x, point[i].y,
					width, height[i]);
			
		}
		
	}
	
}







