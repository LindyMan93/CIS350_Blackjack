/*****************************************************
Extends java.util.Random to provide additional
functionality.

Adapted from code posted on the Web by Charles Stanton
www.math.csusb.edu/faculty/stanton/probstat/poisson.html

One characteristic of the Poisson distribution is
that the mean equals the variance.

@author Scott Grissom
@version October 10, 2005
*****************************************************/
package edu.gvsu;
import java.util.*;

public class GVrandom extends Random{


public static void main(String args[]){
   GVrandom rand = new GVrandom();
   int total = 0;
   int MEAN = 30, COUNT = 20000, var=0;
   for (int i = 1; i<=COUNT; i++){
      int x = rand.nextPoisson(MEAN);
//      System.out.println(x);
      total += x;
      var += (MEAN - x) * (MEAN -x);
   }   

   System.out.println("Desired mean: " + MEAN + " Acual mean: " + total/COUNT + " variance: " + var/COUNT);
}

/*****************************************************
Calculates a random integer using the poisson
distrubution about the desired mean.
@param lambda the desired mean     
@returns a random int about the desired mean
******************************************************/ 
public int nextPoisson(double lambda){
   double elambda = Math.exp(-1*lambda);
   double product = 1;
   int count = 0;
   int result = 0;

   while (product >= elambda){
      product *= nextDouble();
      result = count;
      count++;
   }
return result;   
}   

}