package edu.gvsu;

import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.datatransfer.*;
import java.net.*;

/**
 * This is an abstraction of a single card. This class is implemented as
 * a subclass of JLabel. You are unlikely to use this class
 * <strong>directly</strong> for the project. Use the <tt>Pile</tt>
 * class instead.
 *
 * Use the <tt>getValue()</tt> method to get the integer value of a card
 * (Ace=14, King=13, Queen=12, Jack=11).
 * Use the <tt>getSuit()</tt> method to get the integer representation
 * of the suit (Diamond=0, Heart=1, Spade=2, Club=3). If you need to
 * obtain the String name of the suit, use the <tt>getSuitName()</tt>
 * method.
 *
 * @author Hans Dulimarta
 * @version May 2003 (last updated Oct 2003)
 */
public class GVcard extends JLabel implements Transferable
{
   private static String[] suitNames = {
      "Diamond", "Heart", "Spade", "Club"};
   /* Predefined constants */
   /** constant definition for Jack */
   public final static int JACK = 11; 
   /** constant definition for Queen */
   public final static int QUEEN = 12;
   /** constant definition for King */
   public final static int KING = 13;
   /** constant definition for Ace */
   public final static int ACE = 14;

   /** constant definition for Diamond */
   public final static int DIAMOND = 0;
   /** constant definition for Heart */
   public final static int HEART = 1;
   /** constant definition for Spade */
   public final static int SPADE = 2;
   /** constant definition for Club */
   public final static int CLUB = 3;

   // Image icon for the back face of the card
   private static ImageIcon back_img;
   private static int width, height;

   // Image icon for the front face of the card
   private ImageIcon face_img; 
   private ImageIcon curr_img, mark_img;
   private int value, suit;
   private boolean face_up;

   // The followin static variable is needed for Transferable
   private static DataFlavor FLAVOR;

   /*
    * Initialization block for static variables
    */
   static
   {
      URL u = GVcard.class.getResource ("images/deck0.png");
      back_img = new ImageIcon(u);
      width = back_img.getIconWidth();
      height = back_img.getIconHeight();

      try {
         // Use the following data flavor to enable transfer of object
         // within ONE JVM environment
         FLAVOR = new DataFlavor
            (DataFlavor.javaJVMLocalObjectMimeType);
      }
      catch (ClassNotFoundException _)
      {
         _.printStackTrace();
      }
   }

   /**
    * Constructor.
    *
    * @param value integer value of the card (2, 3, ..., 10, JACK, ..., ACE .
    * @param suit integer value representing the suit of the card (HEART, 
    *     SPADE, CLUB, DIAMOND).
    * @param img_file a JPEG or GIF image to be used for the front face
    * of the card.
    */
   public GVcard(int value, int suit, String img_file)
   {
      this (value, suit, new ImageIcon(img_file));
   }

   /**
    * Constructor, similar to the previous constructor but the front
    * face image is an Icon object.
    *
    * @param value integer value of the card (2, 3, ..., 10, JACK, ..., ACE .
    * @param suit integer value representing the suit of the card (HEART, 
    *     SPADE, CLUB, DIAMOND).
    * @param img an ImageIcon containing the front face of the card.
    */
   public GVcard(int value, int suit, ImageIcon img)
   {
      this.value = value;
      this.suit = suit;
      face_up = false;
      curr_img = back_img;

      face_img = img;

      int w, h;
      w = face_img.getIconWidth();
      h = face_img.getIconHeight();

      setSize (w, h);
      setMinimumSize (new Dimension(w, h));
      setPreferredSize (new Dimension(w, h));
      setMaximumSize (new Dimension(w, h));

      /* In the following block of statement, we create a "reverse" image
       * of the card
       */
      /* first create two RGB images same size as a card */
      BufferedImage bi = new BufferedImage (w, h, 
         BufferedImage.TYPE_INT_RGB);
      BufferedImage bo = new BufferedImage (w, h, 
         BufferedImage.TYPE_INT_RGB);

      /* create a graphic context for the card */
      Graphics2D bi_gcontext = bi.createGraphics();

      /* draw the icon into "bi" (the buffered image) */
      bi_gcontext.drawImage (face_img.getImage(), 0, 0, this);

      /* create a color lookup map */
      byte[] map = new byte[256];
      for (int k = 0; k < map.length - 1; k++)
         map [k] = (byte) (k);
      map[map.length-1] = (byte)128;
      ByteLookupTable blut = new ByteLookupTable (0, map);

      new LookupOp (blut, null).filter(bi, bo);

      /* set the icon from the image */
      face_img = new ImageIcon (bi);
      mark_img = new ImageIcon (bo);
   }

   /**
    * Override the paintComponent() method
    *
    * @param g graphics context
    */
   public void paintComponent (Graphics g)
   {
      super.paintComponent (g);
      setIcon (curr_img);
   }

   /**
    * Set the image (PNG, JPEG, GIF) image of the back of the card
    *
    * @param img_file a JPEG or GIF image to be used for the front face
    * of the card.
    */
   public static void setBackFace (String img_file)
   {
      back_img = new ImageIcon(img_file);
   }

   /**
    * Returns the width of a card
    * @return width (in pixels)
    */
   public static int getCardWidth()
   {
      return width;
   }

   /**
    * Returns the height of a card
    * @return height (in pixels)
    */
   public static int getCardHeight()
   {
      return height;
   }

   /**
    * Mark the card by changing its front face to a "grayscale" image
    */
   public void mark()
   {
      if (face_up)
         curr_img = mark_img;
      repaint();
   }

   /**
    * Unmark the card by restoring its front face image
    */
   public void unMark()
   {
      if (face_up)
         curr_img = face_img;
      repaint();
   }

   /**
    * Check if the card has been marked
    * @return true if the card has been marked, false otherwise.
    */
   public boolean isMarked ()
   {
      return curr_img == mark_img;
   }

   /**
    * Check if the card is facing up
    *
    * @return true/false
    */
   public boolean isUp() { return face_up; }

   /**
    * Check if the card is facing down
    *
    * @return true/false
    */
   public boolean isDown() { return !face_up; }

   /**
    * Check if the card is from a red suit (DIAMOND or HEART)
    *
    * @return true/false
    */
   public boolean isRed() 
   {
      return suit == HEART || suit == DIAMOND;
   }

   /**
    * Check if the card is from a black suit (CLUB or SPADE)
    *
    * @return true/false
    */
   public boolean isBlack() { return !isRed(); }

   /**
    * Get the numerical value of the card
    *
    * @return numerical value of the card (2-14)
    */
   public int getValue() { return value; }

   /**
    * Get the suit of the card
    *
    * @return numerical value of the suit (CLUB, SPADE, HEART,
    * DIAMOND)
    */
   public int getSuit() { return suit; }

   /**
    * Get the name of the suit
    *
    * @return the name of the suit as a String
    */
   public String getSuitName() { return suitNames[suit]; }

   /**
    * Make the card to face up
    */
   public void faceUp() 
   { 
      face_up = true;
      curr_img = face_img;
      repaint(); 
   }

   /**
    * Make the card to face down
    */
   public void faceDown() 
   { 
      face_up = false; 
      curr_img = back_img;
      repaint(); 
   }

   /**
    * Flip the card
    */
   public void flip() 
   { 
      face_up = !face_up; 
      curr_img = curr_img == face_img ?  back_img : face_img;
      repaint(); 
   }

   /** Override the method in the parent class */
   public Dimension getPreferredSize()
   {
      return new Dimension (face_img.getIconWidth(), face_img.getIconHeight());
   }

   /** Override the method in the parent class */
   public Dimension getMinimumSize()
   {
      return getPreferredSize();
   }

   /** Override the method in the parent class */
   public Dimension getMaximumSize()
   {
      return getPreferredSize();
   }

   /** Override the method in the parent class */
   public String toString()
   {
      int v = getValue();
      final String[] num = {"J", "Q", "K", "A"};
      return (v < 11 ? String.valueOf(v) : num[v-11]) + " " + getSuitName();
   }

   public DataFlavor[] getTransferDataFlavors()
   {
      return new DataFlavor[] { FLAVOR };
   }

   public Object getTransferData(DataFlavor f)
      throws UnsupportedFlavorException
   {
      if (!isDataFlavorSupported(f))
         throw new UnsupportedFlavorException (f);
      return this;
   }

   public boolean isDataFlavorSupported (DataFlavor f)
   {
      return FLAVOR.equals(f);
   }
}
