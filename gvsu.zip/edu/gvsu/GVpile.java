package edu.gvsu;

import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.net.*;

/**
 * GVpile is an abstraction of a pile of cards. This class inherits the
 * JLayerPane swing class. Each card in the pile is placed into separate
 * layer.
 *
 * Revision History:
 *     May 2003 created
 *     Oct 2003 constructor now takes a single image
 *     May 2004 get image from jar file
 *
 * @author Hans Dulimarta
 * @version 1.3
 */
public class GVpile extends JLayeredPane
{
   private ArrayList cards;
   private int x_offset, y_offset;

   private static final int X_OFFSET = 5;
   private static final int Y_OFFSET = 0;

   /**
    * Constructor: create a pile of cards and use the image file as the
    * face image of the cards.
    *
    * @param img an image file name (JPG, PNG, or GIF) containing ALL
    * the images of a standard 52-card deck. The images must be arranged
    * into 4 rows, 13 columns. Each row contains cards of one suit in
    * ascending order (2, 3, 4, ..., J, Q, K, A). All diamonds in the
    * first row, hearts in second, spades in third, and clubs in the
    * fourth row.
    * @param mult multiplicity of each card. mult=0 to create an empty
    * pile, mult=1 to create a single deck, mult=2 to create a double
    * deck, mult=3 to create triple deck, ...
    */
   public GVpile (String img, int mult)
   {
      this(img, mult, X_OFFSET, Y_OFFSET);
   }

   /**
    * Similar to the previous constructor, but control the offset of
    * card stacking on the pile
    * @param img an image file name to be used as the face images of the
    * cards.
    * @param mult multiplicity of cards.
    * @param x horizontal offset (may be negative, positive, or zero)
    * @param y vertical offset (may be negative, positive, or zero)
    */
   public GVpile (String img, int mult, int x, int y)
   {
      this (0, x, y);
      createCards(new ImageIcon (img), mult);
   }

   /**
    * Initialize the cards using a default internal image.
    * @param mult multiplicity of cards
    * @param x horizontal offset (may be negative, positive, or zero)
    * @param y vertical offset (may be negative, positive, or zero)
    */
   public GVpile(int mult, int x, int y)
   {
      x_offset = x;
      y_offset = y;
      // Create the array list
      cards = new ArrayList();

      // add a dummy object to an empty pile
      add (Box.createRigidArea (new Dimension (
         GVcard.getCardWidth(), GVcard.getCardHeight())), new Integer (0));

      //addMouseListener (new MouseHandler());
      setAlignmentY (Component.TOP_ALIGNMENT);
      if (mult != 0)
      {
         try {
            Class cl = Class.forName ("edu.gvsu.GVpile");
            URL u = cl.getResource ("images/deck.png");
            //System.err.println (u);
            if (u == null)
               throw new MissingResourceException (
                  "Image file deck.png is not found from " +
                      getClass().getName(), 
                  "GVpile", "GVSU");
            createCards (new ImageIcon(u), mult);
         }
         catch (ClassNotFoundException e)
         {
            e.printStackTrace();
            /*
            throw new MissingResourceException (
               "Image file deck.png is not found", "GVpile", "GVSU");
            */
         }
      }
   }

   /**
    * Create the cards.
    * @param im the image icon for the front face
    * @param mult multiplicity of each card
    */
   protected void createCards (ImageIcon im, int mult)
   {
      int w, h;
      BufferedImage bo;


      w = im.getIconWidth() / 13;
      h = im.getIconHeight() / 4;
      bo = new BufferedImage (w, h, BufferedImage.TYPE_INT_RGB);
      Graphics2D bo_gcontext = bo.createGraphics();
      int layer = 1;
      for (int k = 0; k < 13; k++)
      {
         for (int s=0; s < 4; s++)
         {
            /* copy one card from the source image to the destination
             * card */
            bo_gcontext.drawImage (im.getImage(), 
               0, 0, w, h,                  /* destination area */
               k*w, s*h, (k+1)*w, (s+1)*h,  /* source rectangle */
               null);

            for (int m = 0; m < mult; m++)
            {
               /* create a card from the copied icon */
               GVcard c = new GVcard (k+2, s, new ImageIcon(bo));

               cards.add(c); /* add the card to the the linked list */
               add (c, new Integer(layer));
               layer++;
            }
         }
      }
      recalcPosition();
   }

   /**
    * Redefinition of getPreferredSize()
    */
   public Dimension getPreferredSize ()
   {
      int num = cards.size();
      int w, h;
      if (num == 0)
      {
         return new Dimension (GVcard.getCardWidth(),
            GVcard.getCardHeight());
      }
      else
      {
         num--;
         w = GVcard.getCardWidth() + num * Math.abs(x_offset);
         h = GVcard.getCardHeight() + num * Math.abs(y_offset);
         return new Dimension (w, h);
      }
   }

   /**
    * Redefinition of getMinimumSize()
    */
   public Dimension getMinimumSize() { return getPreferredSize(); }

   /**
    * Redefinition of getMaximumSize()
    */
   public Dimension getMaximumSize() { return getPreferredSize(); }

   /**
    * Redefinition of paintComponent.
    */
   public void paintComponent (Graphics g)
   {
      super.paintComponent (g);
      if (cards.size() == 0)
      {
         /* draw a darker background when no card exists */
         g.setColor (getBackground().darker());
         g.fillRect (0, 0, GVcard.getCardWidth(), GVcard.getCardHeight());
      }
   }

   /**
    * Return the topmost card of the pile or null if the pile is empty.
    *
    * @return return the topmost card if the pile is not empty, or null
    * if the pile is empty.
    */
   public GVcard topCard()
   {
      return (GVcard) (cards.isEmpty() ? null : cards.get(cards.size()-1));
      //return (GVcard) (cards.isEmpty() ? null : cards.getFirst());
   }

   /**
    * Remove the topmost card from the pile.
    *
    * @return return the topmost card if the pile is not empty, or null
    * if the pile is empty.
    */
   public GVcard pop()
   {
      if (cards.isEmpty()) return null;

      // remove the last card in the LinkedList
      //System.out.println (cards.size() + " cards before pop");
      GVcard c = (GVcard) cards.remove(cards.size() - 1);
      //GVcard c = (GVcard) cards.removeFirst();
      
      // remove the card from the layered panel
      remove (lowestLayer());
      if (x_offset < 0 || y_offset < 0)
         recalcPosition();

      repaint();
      return c;
   }

   /**
    * Add a new card to the pile
    *
    * @param c the new card to add
    * @return true if the push was a success, false otherwise.
    */
   public boolean push (GVcard c)
   {
      int layer = cards.size();

      add (c, new Integer (layer)); // add to the panel
      cards.add (c);            // add to the array list
      //setLayer (c, layer);
      if (x_offset > 0 && y_offset > 0)
         c.setLocation (x_offset * layer, y_offset * layer);
      else
         recalcPosition();
      repaint();
      return true;
   }

   /**
    * Shuffle all the cards in the pile
    */
   public void shuffle()
   {
      if (cards.isEmpty()) return;

      Collections.shuffle (cards);

      // Now add the cards back to the layered panel
      for (int k = 0; k < cards.size(); k++)
      {
         GVcard c = (GVcard) cards.get(k);
         setLayer (c, k);
      }
      recalcPosition();
   }

   /**
    * Recalculate the position of all cards in the pile
    */
   private void recalcPosition ()
   {
      int N = cards.size();
      int x_off, y_off;

      for (int k = 0; k < cards.size(); k++)
      {
         GVcard c = (GVcard) cards.get(k);
         x_off = k * x_offset;
         if (x_offset < 0)
            x_off += (N-1) * Math.abs(x_offset);
         y_off = k * y_offset;
         if (y_offset < 0)
            y_off += (N-1) * Math.abs(y_offset);
         c.setLocation (x_off, y_off);
      }
   }

   /*
   The following commented class is to handle Shift-Click mouse button.
   When a card on a GVpile is Shift-Clicked, the card will move to
   foreground the entire image of the card will be visible

   private class MouseHandler extends MouseAdapter
   {
      private GVcard sel_card;
      private int sel_layer;

      public void mousePressed(MouseEvent m)
      {
         // respond only if the Shift key is down
         if (!m.isShiftDown()) return;

         // determine the card selected by the mouse 
         sel_card = getSelected (m);
         if (sel_card != null)
         {
            sel_layer = getLayer (sel_card);
            setLayer (sel_card, cards.size());
            sel_card.mark();
         }
      }

      public void mouseReleased(MouseEvent m)
      {
         if (sel_card != null)
         {
            setLayer (sel_card, sel_layer);
            sel_card.unmark();
            sel_card = null;
         }
      }

      public GVcard getSelected (MouseEvent m)
      {
         int x_index, y_index, last_index;
         GVcard cx, cy;
         boolean in_cx, in_cy;
         Point p = m.getPoint(); // X,Y coordinate of the mouse

         if (cards.isEmpty()) return null;

         last_index = cards.size() - 1;

         // calculate the x-index of card selected by the mouse
         int x_off = x_offset;
         if (x_off > 0)
            x_index = m.getX() / x_off;
         else if (x_off < 0)
            x_index = (int)(getPreferredSize().getWidth() - m.getX()) 
               / -x_off;
         else
            x_index = 0;
         x_index = Math.min (last_index, x_index);

         // calculate the y-index of card selected by the mouse
         int y_off = y_offset;
         if (y_off > 0)
            y_index = m.getY() / y_off;
         else if (y_off < 0)
            y_index = (int)(getPreferredSize().getHeight() - m.getY()) 
               / -y_off;
         else
            y_index = 0;
         y_index = Math.min (last_index, y_index);

         cx = (GVcard) cards.get (x_index);
         // first check whether the mouse is OVER the card
         in_cx = cx.getBounds().contains (p);
         if (x_index == y_index)
         {
            if (in_cx) return cx;
         }
         else {
            cy = (GVcard) cards.get (y_index);
            in_cy = cy.getBounds().contains (p);

            if (in_cx && in_cy)
               return x_index > y_index ? cx : cy;
            else if (in_cx)
               return cx;
            else if (in_cy)
               return cy;
         }
         return null;
      }
   }
   */
   public void dumpLayers()
   {
      System.out.print ("Dump layers: ");
      for (int i=lowestLayer(); i <= highestLayer(); i++)
      {
         int num = getComponentCountInLayer(i);
         if (num != 1)
            System.out.print ("L" + i + ":" + num + " ");
      }
      System.out.println();
   }
}
